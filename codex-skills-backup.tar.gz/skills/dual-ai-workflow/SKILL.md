---
name: dual-ai-workflow
description: Three-tool AI engineering loop. Codex is the lead engineer for planning, staged implementation, commands, tests, fixes, handoff summaries, and git archival. Claude Code in VS Code is the reviewer for architecture review, code review, risk checks, P0/P1/P2 classification, and re-review. Claude Desktop is the requirements and writing advisor used through copied prompts or pasted documents, not a third-party skills installation environment.
---

# 三方 AI 工作流（Codex × Claude Code in VS Code × Claude Desktop）

## 啟動規則

被觸發或接手時，先檢查並讀取專案根目錄 `DUAL-AI-STATE.md`。如果檔案存在，以狀態檔為準接續工作，不依賴對話記憶；如果不存在，才依使用者貼上的內容判斷階段。

## 角色定義

| 角色 | 負責事項 | 不做的事 |
|---|---|---|
| Codex | 主力工程師：規劃、分段實作、跑指令、測試、修正、產出交接摘要、git 存檔 | 不跳過審查；高風險動作先說明再做 |
| Claude Code（VS Code） | 審查員：架構建議、程式碼審查、風險檢查、P0/P1/P2 分級、複審 | 不取代 Codex 做整段主力開發，除非使用者明確指定小範圍修正 |
| Claude Desktop | 顧問／文字助理：需求澄清、文件整理、提示詞優化、主管版說明 | 不安裝第三方 skills，不直接操作本機檔案 |
| 使用者 | 三方之間轉貼訊息、做最終決定 | 不需要懂技術細節 |

## 多裝置同步

- Windows 常見安裝目錄：`~/.codex/skills/dual-ai-workflow/`、`~/.claude/skills/dual-ai-workflow/`
- macOS / Mac mini 常見安裝目錄：`~/.codex/skills/dual-ai-workflow/`、`~/.claude/skills/dual-ai-workflow/`
- VS Code 裡的 Claude Code 要確認能讀到同一份 `~/.claude/skills/dual-ai-workflow/SKILL.md`；如果某個環境使用不同 skill 路徑，要同步那一份
- Claude Desktop 不當作第三方 skills 安裝環境；使用 Claude Desktop 時，改用控制台「提示詞庫」或手動貼工作流文件

## 狀態檔機制

每個階段結束時，自動建立或更新專案根目錄 `DUAL-AI-STATE.md`，固定欄位：任務名稱／目前階段／已完成事項／下一步／未解決問題／最後更新時間。

任務閉環完成時，不刪除 `DUAL-AI-STATE.md`，只把目前階段標記為「✅ 已完成」。

## 五階段工作流

### 第一階段：Codex 規劃

Codex 先讀專案結構與文件，不要修改。提出方案：任務目標、要改哪些檔案、可能影響哪些功能、風險與不確定點、修改後如何驗證。等使用者確認後進入第二階段。

### 第二階段：Codex 分段實作

Codex 依確認後的方案分段實作、執行必要指令、跑 build 或測試、回報改了哪些檔案與驗證結果。結尾輸出「給 Claude Code（VS Code）的完整轉交提示詞」，附上交接摘要、改動檔案、驗證結果、未確認事項與 diff。

### 第三階段：Claude Code（VS Code）審查

Claude Code（VS Code）審查 Codex 的改動、diff 與驗證結果，依 P0／P1／P2 排序，指出檔案與原因。結尾輸出「給 Codex 的完整轉交提示詞」。

### 第四階段：Codex 修正

Codex 逐條判斷審查意見：成立就只改必要檔案並重新驗證，不成立就說明理由。完成後輸出「給 Claude Code（VS Code）的完整轉交提示詞」，附上逐條處理結果、重新驗證結果與新 diff。

### 第五階段：Claude Code（VS Code）複審

Claude Code（VS Code）逐條對照前一輪問題是否已處理，並檢查是否引入新問題。全部通過時，輸出「閉環完成」與「給 Codex 的存檔轉交提示詞」；仍有問題時，輸出給 Codex 的修正提示詞，回到第四階段。

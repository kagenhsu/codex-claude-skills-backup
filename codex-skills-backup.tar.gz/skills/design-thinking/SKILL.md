---
name: design-thinking
description: Human-centered design thinking for product, service, and workflow problems. Use when framing ambiguous user problems, planning discovery, ideating solutions, prototyping concepts, running workshops, or testing early ideas.
---

# Design Thinking

Use this skill to guide human-centered problem solving through the five common Design Thinking phases: empathize, define, ideate, prototype, and test.

## When to Use

Use this skill when the user asks to:

- Explore a messy or ambiguous problem.
- Understand users, customers, stakeholders, or workflows.
- Turn research into a clear problem statement.
- Generate or compare solution ideas.
- Plan a workshop, sprint, prototype, or user test.
- Improve a product, service, onboarding flow, internal process, or feature concept.

Do not jump straight to solutions. First identify what is known, what is assumed, and what still needs to be learned.

## Core Principles

- **Human-centered:** Start with real people, context, motivations, and constraints.
- **Problem-first:** Separate symptoms from root needs before proposing solutions.
- **Diverge and converge:** Generate breadth, then select based on evidence and goals.
- **Make it tangible:** Use sketches, storyboards, service blueprints, or low-fidelity prototypes early.
- **Iterate quickly:** Treat tests as learning loops, not final judgment.
- **Collaborate broadly:** Include people with different roles, expertise, and lived experience.

## Workflow

### 1. Empathize

Goal: understand the people affected by the problem.

Ask:

- Who experiences this problem most directly?
- What are they trying to accomplish?
- What frustrates, slows, confuses, or worries them?
- What workarounds have they invented?
- What does success feel like from their point of view?

Useful methods:

- User interviews.
- Contextual observation.
- Empathy maps.
- Journey maps.
- Stakeholder maps.
- Support-ticket or feedback analysis.

Output:

- Key observations.
- User quotes or evidence.
- Needs, pains, gains, constraints, and context.

### 2. Define

Goal: frame the right problem in a useful way.

Create a point-of-view statement:

```markdown
[User/persona] needs to [need/action] because [insight/evidence].
```

Then turn it into How Might We questions:

```markdown
How might we help [user] [achieve outcome] despite [constraint]?
How might we reduce [pain] without sacrificing [important value]?
How might we make [desired behavior] easier, clearer, or more rewarding?
```

Good problem frames are:

- Specific enough to act on.
- Broad enough to allow multiple solutions.
- Grounded in user evidence.
- Connected to business or organizational goals.

### 3. Ideate

Goal: generate multiple possible directions before choosing.

Run ideation with these rules:

- Defer judgment during generation.
- Aim for quantity before quality.
- Build on ideas with "yes, and".
- Include obvious, strange, small, and ambitious ideas.
- Make ideas visible with sketches, flows, or short concept cards.

Techniques:

- Brainstorming.
- Brainwriting.
- Crazy 8s.
- SCAMPER.
- Worst possible idea.
- Analogy prompts.
- Opportunity-solution trees.

Converge by evaluating:

- User value.
- Feasibility.
- Risk.
- Learning potential.
- Strategic fit.
- Time to prototype.

### 4. Prototype

Goal: make an idea testable with minimal effort.

Choose the lowest fidelity that can answer the question:

- Sketch or paper prototype.
- Storyboard.
- Clickable mockup.
- Role play.
- Wizard-of-Oz flow.
- Landing-page test.
- Concierge or manual version.

Before prototyping, define:

```markdown
Concept:
Learning goal:
Target user:
What to include:
What to exclude:
Key assumptions:
Success signal:
Timebox:
```

### 5. Test

Goal: learn what works, what fails, and what to change.

Plan tests around behavior, not opinions:

- Give users a realistic scenario.
- Ask them to think aloud.
- Watch what they do before asking what they think.
- Ask "why" after reactions.
- Capture surprises, confusion, hesitation, and delight.
- Separate findings from interpretations.

Test synthesis:

```markdown
What worked:
What confused users:
What assumptions changed:
What should we keep:
What should we change:
What should we test next:
```

## Workshop Formats

### 60-Minute Problem Framing

- 10 min: align on challenge and constraints.
- 15 min: share user evidence.
- 15 min: map pains, needs, and current journey.
- 10 min: draft POV statements.
- 10 min: choose priority How Might We questions.

### Half-Day Design Thinking Workshop

- 30 min: challenge framing and user context.
- 45 min: empathy mapping or journey mapping.
- 45 min: define POV and HMW questions.
- 60 min: ideation.
- 60 min: prototype concepts.
- 30 min: share, critique, and choose next tests.

### One-Day Sprint

- Morning: understand the problem, map the journey, and select a target.
- Midday: sketch and decide on a concept.
- Afternoon: prototype and run lightweight tests or expert reviews.
- Close: document learnings, risks, and next actions.

## Response Pattern

When using this skill:

1. Identify which phase the user is in.
2. Ask only the missing questions needed to move forward.
3. Make assumptions explicit.
4. Produce a tangible artifact: interview guide, POV, HMW list, idea matrix, prototype plan, test script, or workshop agenda.
5. Recommend the next smallest learning step.

Keep the process practical. The goal is not to perform a ritual; it is to reduce uncertainty and design something people can actually use.
